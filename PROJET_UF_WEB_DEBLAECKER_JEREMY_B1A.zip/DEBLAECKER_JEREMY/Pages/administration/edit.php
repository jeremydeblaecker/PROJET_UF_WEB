<?php

include 'config.php';

if(isset($_GET['id'])){
    $id=$_GET['id'];
}

$selectUtilisateur="SELECT * FROM web WHERE id=".$id;
$user=selectUtilisateur($selectUtilisateur);

if(isset($_POST['submit'])){
 $name=$_POST['expediteur'];
 $name=$_POST['mail'];
 $name=$_POST['texte'];
 $query="UPDATE web SET expediteur='" .$expediteur . "',mail='" .$mail ."',texte='".$texte."', id='".$id."'";
}

$update=updateUtilisateur($query);
if($update !=0){
    echo 'Utilisateur MAJ';
}else{
    echo 'erreur';
}
?>
<form method="post">
    <input type="texte" name="expediteur" value="<?php echo $user['expediteur']?>"> <br>
    <input type="texte" name="mail"	value="<?php echo $user['mail']?>"><br>
    <input type="texte" name="texte" value="<?php echo $user['texte']?>"><br>
    <input type="submit" name="submit" value="Edit"><br>
</form>