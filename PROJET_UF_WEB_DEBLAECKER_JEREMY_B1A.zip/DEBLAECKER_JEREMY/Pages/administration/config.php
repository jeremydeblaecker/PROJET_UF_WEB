<?php

function getConnection() {
    $con=new PDO ("mysql:host=db5000109013.hosting-data.io; dbname=dbs103504", "dbu324224", "");
    $con ->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $con;
}

function selectUtilisateur($query){
    $pdo= getConnection();

    $stmt=$pdo->query($query);
    return $stmt->fetchAll();
}

function updateUtilisateur($query){
    $pdo=getConnection();
    $stmt=$pdo->prepare($query);
    return $stmt->execute();
}
?>